package com.firebow.event;

import com.firebow.util.*;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    // Entity ID dedup
    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private static final long ARROW_DEDUP_WINDOW_MS = 3000L;

    // Pending carts — đặt trong beforeSync thay vì onClientTick
    // Key: pos, Value: [ticksLeft, retryCount, syncReady]
    // syncReady=1 nghĩa là đã sẵn sàng đặt ngay khi beforeSync được gọi
    private final Map<BlockPos, int[]> pendingCarts = new ConcurrentHashMap<>();
    private static final int MAX_CART_RETRIES = 8;

    private final TickSynchronizer tickSync = new TickSynchronizer();
    private volatile boolean enabled = true;

    private FireBowRuntime() {}

    public boolean isEnabled()           { return enabled; }
    public void    toggle()              { enabled = !enabled; }

    public boolean isDuplicateArrow(int entityId) {
        Long lastMs = acceptedArrows.get(entityId);
        return lastMs != null &&
            (System.currentTimeMillis() - lastMs) < ARROW_DEDUP_WINDOW_MS;
    }

    public void acceptArrow(int entityId, BlockPos railPos, int tickDelay) {
        acceptedArrows.put(entityId, System.currentTimeMillis());
        AsyncRunner.runDelayed(() -> acceptedArrows.remove(entityId), ARROW_DEDUP_WINDOW_MS);
        // syncReady=0 khi mới tạo, đếm ngược từ tickDelay
        pendingCarts.put(railPos, new int[]{ tickDelay, 0, 0 });
    }

    public void onClientTick(MinecraftClient client) {
        tickSync.onClientTick();
        if (pendingCarts.isEmpty()) return;
        if (client.player == null || client.world == null) return;
        if (!enabled) { pendingCarts.clear(); return; }

        Iterator<Map.Entry<BlockPos, int[]>> iter = pendingCarts.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<BlockPos, int[]> entry = iter.next();
            BlockPos pos  = entry.getKey();
            int[] state   = entry.getValue(); // [0]=ticksLeft [1]=retryCount [2]=syncReady

            if (state[2] == 1) continue; // đang chờ beforeSync xử lý

            state[0]--;
            if (state[0] > 0) continue;

            // Tick đến — thử đặt ngay
            boolean hasRail =
                client.world.getBlockState(pos).isOf(Blocks.RAIL) ||
                client.world.getBlockState(pos).isOf(Blocks.POWERED_RAIL);

            if (hasRail) {
                // Rail đã có → đặt cart ngay, không chờ beforeSync
                iter.remove();
                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (!cart.isMissing() && client.interactionManager != null) {
                    int saved = client.player.getInventory().selectedSlot;
                    client.player.getInventory().selectedSlot = cart.slot;
                    InteractionUtil.placeOnTop(client, pos);
                    client.player.getInventory().selectedSlot = saved;
                }
            } else if (state[1] < MAX_CART_RETRIES) {
                // Rail chưa spawn → đánh dấu syncReady, beforeSync sẽ retry
                state[2] = 1;
                state[1]++;
            } else {
                iter.remove();
            }
        }
    }

    /**
     * beforeSync — fallback khi rail chưa spawn kịp trong onClientTick.
     * Đặt cart cùng lúc movement packet → anti-cheat safe cho retry.
     */
    public void beforeSync() {
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        Iterator<Map.Entry<BlockPos, int[]>> iter = pendingCarts.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<BlockPos, int[]> entry = iter.next();
            BlockPos pos  = entry.getKey();
            int[] state   = entry.getValue();
            if (state[2] != 1) continue;

            boolean hasRail =
                mc.world.getBlockState(pos).isOf(Blocks.RAIL) ||
                mc.world.getBlockState(pos).isOf(Blocks.POWERED_RAIL);

            if (hasRail) {
                iter.remove();
                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (!cart.isMissing()) {
                    int saved = mc.player.getInventory().selectedSlot;
                    mc.player.getInventory().selectedSlot = cart.slot;
                    InteractionUtil.placeOnTop(mc, pos);
                    mc.player.getInventory().selectedSlot = saved;
                }
            } else if (state[1] < MAX_CART_RETRIES) {
                // Retry lần nữa sau 1 tick
                state[0] = 1;
                state[2] = 0;
            } else {
                iter.remove();
            }
        }
    }
}
